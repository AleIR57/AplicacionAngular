<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "subasya";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

if (isset($_GET["ingresar"])){
	$data = json_decode(file_get_contents("php://input"));
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $sqlUsuaarios = mysqli_query($conexionBD,"SELECT * FROM usuario WHERE correo='$correo' and contrasena ='$contrasena'");
    if(mysqli_num_rows($sqlUsuaarios) > 0){
        $usuaarios = mysqli_fetch_all($sqlUsuaarios,MYSQLI_ASSOC);
        echo json_encode($usuaarios);
        exit();
    }
    else{  
    	echo json_encode(["success"=>0]); }
}

if (isset($_GET["registrar"])){
	$data = json_decode(file_get_contents("php://input"));
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $sqlUsuaarios = mysqli_query($conexionBD,"SELECT * FROM usuario WHERE correo='$correo'");
    if(mysqli_num_rows($sqlUsuaarios) > 0){
    	echo json_encode(["success"=>0]);
        
    }
    else{  
    	 $data = json_decode(file_get_contents("php://input"));
    $nombre=$data->nombre;
    $apellido=$data->apellido;
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $telefono=$data->telefono;
    $direccion=$data->direccion;
    $cedula=$data->cedula;
    $foto=$data->foto;
    $fecharegistro=$data->fecharegistro;
    $idrol=$data->idrol;
        if(($correo!="")&&($nombre!="")&&($apellido!="")&&($correo!="")&&($contrasena!="")&&($telefono!="")&&($direccion!="")&&($cedula!="")&&($foto!="")&&($fecharegistro!="")&&($idrol!="")){
            
    $sqlUsuaarios = mysqli_query($conexionBD,"INSERT INTO usuario(nombre,apellido,correo,contrasena,telefono,direccion,cedula,foto,fecharegistro,idrol) VALUES('$nombre','$apellido','$correo','$contrasena','$telefono','$direccion','$cedula','$foto','$fecharegistro','$idrol')");
    echo json_encode(["success"=>1]);
        }
    exit(); }
}

?>