<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "subasya";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);


// Consulta datos y recepciona una clave para consultar dichos datos con dicha clave
if (isset($_GET["consultar"])){
    $sqlUsuaarios = mysqli_query($conexionBD,"SELECT * FROM usuario WHERE idUsuario=".$_GET["consultar"]);
    if(mysqli_num_rows($sqlUsuaarios) > 0){
        $usuaarios = mysqli_fetch_all($sqlUsuaarios,MYSQLI_ASSOC);
        echo json_encode($usuaarios);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//borrar pero se le debe de enviar una clave ( para borrado )
if (isset($_GET["borrar"])){
    $sqlUsuaarios = mysqli_query($conexionBD,"DELETE FROM usuario WHERE idUsuario=".$_GET["borrar"]);
    if($sqlUsuaarios){
        echo json_encode(["success"=>1]);
        exit();
    }
    else{  echo json_encode(["success"=>0]); }
}
//Inserta un nuevo registro y recepciona en método post los datos de nombre y correo
if(isset($_GET["insertar"])){
    $data = json_decode(file_get_contents("php://input"));
    $nombre=$data->nombre;
    $apellido=$data->apellido;
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $telefono=$data->telefono;
    $direccion=$data->direccion;
    $cedula=$data->cedula;
    $foto=$data->foto;
    $fecharegistro=$data->fecharegistro;
    $idrol=$data->idrol;
        if(($correo!="")&&($nombre!="")&&($apellido!="")&&($correo!="")&&($contrasena!="")&&($telefono!="")&&($direccion!="")&&($cedula!="")&&($foto!="")&&($fecharegistro!="")&&($idrol!="")){
            
    $sqlUsuaarios = mysqli_query($conexionBD,"INSERT INTO usuario(nombre,apellido,correo,contrasena,telefono,direccion,cedula,foto,fecharegistro,idrol) VALUES('$nombre','$apellido','$correo','$contrasena','$telefono','$direccion','$cedula','$foto','$fecharegistro','$idrol')");
    echo json_encode(["success"=>1]);
        }
    exit();
}
// Actualiza datos pero recepciona datos de nombre, correo y una clave para realizar la actualización
if(isset($_GET["actualizar"])){
    
    $data = json_decode(file_get_contents("php://input"));

    $idUsuario=(isset($data->idUsuario))?$data->idUsuario:$_GET["actualizar"];
    $nombre=$data->nombre;
    $apellido=$data->apellido;
    $correo=$data->correo;
    $contrasena=$data->contrasena;
    $direccion=$data->direccion;
    $telefono=$data->telefono;
    $cedula=$data->cedula;
    $foto=$data->foto;
    $idRol=$data->idRol;

    
    $sqlUsuaarios = mysqli_query($conexionBD,"UPDATE usuario SET nombre='$nombre',apellido='$apellido',correo='$correo',contrasena='$contrasena',telefono='$telefono',direccion='$direccion',cedula='$cedula',foto='$foto',idRol='$idRol' WHERE idUsuario='$idUsuario'");
    echo json_encode(["success"=>1]);
    exit();
}
// Consulta todos los registros de la tabla empleados
$sqlUsuaarios = mysqli_query($conexionBD,"SELECT * FROM usuario ");
if(mysqli_num_rows($sqlUsuaarios) > 0){
    $usuaarios = mysqli_fetch_all($sqlUsuaarios,MYSQLI_ASSOC);
    echo json_encode($usuaarios);
}
else{ echo json_encode([["success"=>0]]); }


?>
