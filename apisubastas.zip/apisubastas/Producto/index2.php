<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET,POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Conecta a la base de datos  con usuario, contraseña y nombre de la BD
$servidor = "localhost"; $usuario = "root"; $contrasenia = ""; $nombreBaseDatos = "subasya";
$conexionBD = new mysqli($servidor, $usuario, $contrasenia, $nombreBaseDatos);

if (isset($_GET["consultar5"])){
    $sqlOfertaas3 = mysqli_query($conexionBD,"SELECT usuario.* FROM producto, usuario WHERE producto.idUsuario = usuario.idUsuario and idProducto = ".$_GET["consultar5"].";");
if(mysqli_num_rows($sqlOfertaas3) > 0){
    $ofertaas3 = mysqli_fetch_all($sqlOfertaas3,MYSQLI_ASSOC);
    echo json_encode($ofertaas3);
}
else{ echo json_encode([["success"=>0]]); }
}

?>